from src.loss.example import ExampleLoss
from src.loss.amsoftmax import AMSoftmaxLoss
