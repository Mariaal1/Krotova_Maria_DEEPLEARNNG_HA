import torch
from torch import nn
import torch.nn.functional as F


class AMSoftmaxLoss(nn.Module):
    def __init__(self, margin=0.35, scale=30.0):
        super().__init__()
        self.margin = margin
        self.scale = scale

    def forward(self, logits, labels):
        one_hot = F.one_hot(labels, num_classes=logits.shape[1])
        logits = logits - one_hot * self.margin
        return F.cross_entropy(self.scale * logits, labels)
