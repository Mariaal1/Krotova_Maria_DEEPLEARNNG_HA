from src.metrics.example import ExampleMetric
